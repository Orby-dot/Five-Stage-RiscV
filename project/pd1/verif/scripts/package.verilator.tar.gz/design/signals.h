
/* Your Code Below! Enable the following define's 
 * and replace ??? with actual wires */
// ----- signals -----
`define F_PC                address
`define F_INSN              data_out

// ----- signals -----

// ----- design -----
`define TOP_MODULE                 pd
// ----- design -----
